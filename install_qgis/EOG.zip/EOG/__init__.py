def classFactory(iface):
    from .EOGPlugin import EOGPlugin
    return EOGPlugin(iface)
